A Pen created at CodePen.io. You can find this one at http://codepen.io/css-tricks/pen/pvamyK.

 Demo for this CSS Tricks tutorial: http://css-tricks.com/seamless-responsive-photo-grid/